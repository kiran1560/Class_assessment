#include<iostream>
using namespace std;

template<typename T>
T maximum(T a, T b, T c) //space is necessary eg. (int a, int b, int c)
{
	T maximum;
	
	maximum =a;
	if(b>maximum)
	
	maximum =b;
	if(c>maximum)
	maximum =c;
	
	return maximum;
}
int main(){
	cout<<maximum(10,20,40)<<endl;
	cout<<maximum(10.2,20.3,40.6)<<endl;
	cout<<maximum('u','t','y');
	
}
