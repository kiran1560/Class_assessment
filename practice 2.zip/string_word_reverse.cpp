#include <iostream>
#include <string>

using namespace std;

int main() {
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    string currentWord;
    for (size_t i = 0; i <= inputString.length(); ++i) {
        char ch = i < inputString.length() ? inputString[i] : ' ';

        if (isspace(ch)) {
            // Print the current word in reverse
            for (int j = currentWord.length() - 1; j >= 0; --j) {
                cout << currentWord[j];
            }

            // Print a space if not the last character
            if (i < inputString.length()) {
                cout << ' ';
            }

            currentWord.clear();
        } else {
            currentWord += ch;
        }
    }

    cout << endl;

    return 0;
}

