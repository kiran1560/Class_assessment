#include<iostream>
#include<fstream>
using namespace std;

namespace name 
{
	int val=200;
}

int main()
{
int val=600;
cout<<val<<endl;

cout<<name::val;
return 0;
}
