#include<iostream>
using namespace std;

int main() {
    int n = 5;
    int arr[5];
    int count = 0, target;

    cout << "Enter the 5 elements of the array: " << endl;

    for (int i = 0; i < n; i++)
	 {
        cin >> arr[i];
    }

   cout << "Enter the target number to count its occurrences: ";
    cin >> target;

    for (int i = 0; i < n; i++) 
	{
        if (arr[i] == target) 
		{
            count++;
        }
    }

    cout << "The number " << target << " occurs " << count << " times." << endl;

    return 0;
}

