#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	fstream myfile("file.txt");
	if(!myfile.is_open())
	{
		cout<<"error";
}
else
	{
	cout<<myfile.tellp();
	string line;
	myfile.seekg(2);
	getline(myfile,line);
	cout<<line;
	
}
	

}
