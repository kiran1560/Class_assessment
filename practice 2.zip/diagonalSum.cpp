#include <iostream> 
using namespace std; 
  
const int MAX = 100; 
  
void diagonalSums(int mat[][MAX], int n) 
{ 
    int left = 0, right = 0;  
    for (int i = 0; i < n; i++)  
    { 
        left += mat[i][i]; 
        right += mat[i][n - i - 1];         
    } 
  
    cout << "Left Diagonal:" <<  left << endl; 
    cout << "Right Diagonal:" << right << endl; 
}

int main() 
{ 
    int a[][MAX] = {{10, 2, 3, 1},  
                    {5, 20, 2, 8},  
                    {1, 3, 30, 4},  
                    {4, 6, 7, 40}}; 
                    
    diagonalSums(a, 4); 
    return 0; 
} 
