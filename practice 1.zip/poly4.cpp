#include <iostream>

using namespace std;
class Game
{
	public:
	void play(int a, string s){
			cout<<"cricket"<<endl;
		}
	void place(string s, int a ){
			cout<<"football"<<endl;
		}

};
int main(){
	Game g;
    g.play(8, "kohli");
    g.play("Sunil", 9);
	
}


//sequence of arguments
