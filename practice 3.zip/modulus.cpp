#include <iostream>

using namespace std;

void countDivMod(const int arr[], int size, int divisor) {
    int divisibleCount = 0;

    cout << "Modulus for each element and count of elements divisible by " << divisor << ":\n";

    for (int i = 0; i < size; ++i) {
        int modulus = arr[i] % divisor;

        cout << "Element: " << arr[i] << ", Modulus: " << modulus << endl;

        if (modulus == 0) {
            divisibleCount++;
        }
    }

    cout << "Total elements divisible by " << divisor << ": " << divisibleCount << endl;
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int divisor;
    cout << "Enter the divisor: ";
    cin >> divisor;

    countDivMod(arr, size, divisor);

    return 0;
}

