#include<iostream>
using namespace std;
int main()

{
int i,j,n,k;
cout<<"enter value of n: ";
cin>>n;

//upper portion 
for(i = 0; i <= n; i++)
{
for(k= n; k> i; k--)
cout << " ";
for(j=0; j<i; j++)
cout << "*";
cout << "\n";
}
	
for(i=0;i<n;i++)
{
for(k= 1; k<n; k++)
cout << " ";
for(j=n; j>i; j--)
{

cout << "*";}
cout << "\n";
}
	
	return 0;
}

