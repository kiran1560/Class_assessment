#include<iostream>
using namespace std;
int main()

{
int i,j,n;
cout<<"enter value of n: ";
cin>>n;

//upper portion with space
for(i=1;i<=n; i++)
{    
for(j=i;j<n;j++)
		
	{
	cout<<" ";
	}
	
	for(j=1;j<=i; j++)
	
	{
		cout<<"*";
	}
		cout<<endl;
	}
	
	//lower portion
for(i=n;i>=1; i--)
{
	for(j=i;j<n;j++)
		
	{
	cout<<" ";
	}
	
	for(j=1;j<=i; j++)
	
	{
		cout<<"*";
	}
		cout<<endl;
	}
	return 0;
}

