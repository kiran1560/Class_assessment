#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ofstream file("file.txt");
	if(!file.is_open())
	{
		cout<<"no such file found";
	}
	else
	{
		file<<"write ist line on file \n";
		file<<"write second line on file \n";
		file.close();
	cout<<"Sucess";
	

return 0;	
}}
