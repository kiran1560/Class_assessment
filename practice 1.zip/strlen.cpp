#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char a[50]="toy";
   int n=strlen(a);
    
     
	 	cout<<"size for a: "<<n;

    return 0;
}

