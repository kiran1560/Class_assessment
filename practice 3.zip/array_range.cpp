#include <iostream>

using namespace std;

pair<int, int> range(const int arr[], int size) {
    int start = arr[0];
    int end = arr[0];
    int currentStart = arr[0];
    int currentEnd = arr[0];

    for (int i = 1; i < size; ++i) {
        if (arr[i] == currentEnd + 1) {
            currentEnd = arr[i];
        } else {
            if (currentEnd - currentStart > end - start) {
                start = currentStart;
                end = currentEnd;
            }

            currentStart = arr[i];
            currentEnd = arr[i];
        }
    }


    if (currentEnd - currentStart > end - start) {
        start = currentStart;
        end = currentEnd;
    }

    return make_pair(start, end);
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int *arr = new int[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; ++i) {
        cin >> arr[i];
    }

    pair<int, int> result = range(arr, size);

    cout << "Longest continuous range: [" << result.first << ", " << result.second << "]\n";

    delete[] arr;

    return 0;
}

