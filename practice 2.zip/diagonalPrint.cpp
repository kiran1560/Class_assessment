#include <iostream>
using namespace std;

const int MAX = 100;

void d1(int mat[][MAX], int n)
{

    cout << "Diagonal 1 : ";
    for (int i = 0; i < n; i++) 
	{
        cout << mat[i][i] << ", ";
    }
    cout << endl;
}
void d2(int mat[][MAX], int n)
{

    cout << " Diagonal 2 : ";
    int k = n - 1;
    for (int i = 0; i < n; i++) {

        cout << mat[i][k--] << ", ";
    }
   cout << endl;
}
 
int main()
{

    int n = 4;
    int a[][MAX] = { { 1, 2, 3, 4 },
                     { 5, 6, 7, 8 },
                     { 1, 2, 3, 4 },
                     { 5, 6, 7, 8 } };
 
    d1(a, n);
    d2(a, n);

    return 0;
}
