#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	string line;
	fstream file("file.txt");
	if(!file.is_open())
	{
		while(getline(file,line))
		{
		
		cout<<line<<endl;
	}
	file.close();
}
else
	{
	cout<<"unable to find the file";
}
	

}
