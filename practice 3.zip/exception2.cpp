#include<iostream>
#include<exception>
#include<stdexcept>
using namespace std;
int main()
{
	
	cout<<"start \n";
	int a=10, b=0;
	
	try{
		if(b==0)
		  {
			throw runtime_error("Error"); //in built function
		  } 
			cout<<a/b;
	}
		                              
	catch(runtime_error(error)) 
	{
		cout<<"exception occured: ";
		cout<<error.what();		
	}
	
	cout<<"\n end \n";
	return 0;
}
