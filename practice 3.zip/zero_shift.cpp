#include<iostream>
using namespace std;

int main()
{
    int arr[50], n, nonZero = 0;
    cout<<"Enter the size of array: ";
    cin>>n;
    cout<<"Input the numbers: ";
    for(int i = 0; i < n ; i++)
        cin>>arr[i];
        
    for(int i = 0; i < n; i++){
        if(arr[i] != 0){
            arr[nonZero] = arr[i];
            nonZero++;
        }
    }
    
    for(int i = nonZero; i < n; i++)
        arr[i] = 0;
     
    cout<<"\n Array after moving all the zero at the end: ";
    for(int i = 0; i < n; i++)
        cout<<arr[i]<<" ";
    return 0;
}
