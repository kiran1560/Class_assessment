#include <iostream>
#include <cstring>
using namespace std;

int main(){
	int a;
	cin>>a;
	int b=a*a;
	cout<<b<<endl;
	
	if(b%a ==a)
	{
		cout<<"auromorphic"<<endl;
	}
	else
{
	cout<<"not";
}
}
