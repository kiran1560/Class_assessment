#include <iostream>
#include <cstring>
using namespace std;
typedef unsigned int Var;

int main() {
    int a=10;
    int b=2;
    int c=a+b;
    cou<<c;

    return 0;
}


