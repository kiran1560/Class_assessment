#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char a[50];
    cin>>a;
    int n=strlen(a);
    //int count=0; //do yourself
  
    
    for(int i=0;i<n;i++)
     {
     if(a[i]=='a' ||a[i]=='e' ||a[i]=='i' || a[i]=='o' || a[i]=='u' || a[i]=='A' || a[i]=='E' || a[i]=='I' || a[i]=='O' || a[i]=='U'> a[i]==a[i+1] )
	 { 
	 cout<<" ";
		 }
		 else
	{
		 cout<<a[i];	
			 }	
	 }
   
}

