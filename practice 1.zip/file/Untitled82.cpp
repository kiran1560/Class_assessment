#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ofstream file;
	file.open("file.txt");
	file<<"creating a file";
	file.close();
return 0;	
}
