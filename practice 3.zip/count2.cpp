#include <iostream>
#include <string>
using namespace std;

class Occurrance {
    string str;
    char target;

public:
    void wordcount() {
        str = "ftf@fdfd@";
        target = '@';
    }
     
    void countOccurrance() {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str[i] == target) {
                count++;
            }
        }
        cout << "The character '" << target << "' occurs " << count << " times in the string." << endl;
    }
};

int main() {
    Occurrance o;
    o.wordcount();
    o.countOccurrance();

    return 0;
}

