#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char a[50];
    char b[50];
     cin>>a>>b;
     
     if(strcmp(a,b)==0)
     {
     	cout<<"correct";
	 }
	 else
	 {
	 	cout<<"not correct";
	 }

    return 0;
}

