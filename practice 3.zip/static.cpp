#include<iostream>
#include<fstream>
using namespace std;
int main()
{
float mul =3.5*2.1;
int res=static_cast<int>(mul);

cout<<res;
return 0;
}
