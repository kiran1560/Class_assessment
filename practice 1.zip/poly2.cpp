#include <iostream>

using namespace std;
class Hotel
{
	public:
		void eat(int a){
			cout<<"dosa"<<endl;
		}
		void eat(float b){
			cout<<"pizza"<<endl;
		}
		void eat(string s){
			cout<<"burger"<<endl;
		}
};
int main(){
	Hotel h;
	h.eat(10);
	h.eat(10.0f);
	h.eat("string value");
}


//same name but different parameters

