#include<iostream>
using namespace std;
void wavearray(int arr[],int n)
{

for(int i=0;i<n;i=i+2)
{
swap(arr[i],arr[i+1]);
}
}
int main()
{
int n=6;
int arr[6]={2,4,6,8,9,10};
wavearray(arr,n);
for(int i=0;i<n;i++)
{
cout<<arr[i]<<" ";
}
}
