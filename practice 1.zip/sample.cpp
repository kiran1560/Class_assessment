#include <iostream>

using namespace std;
class Student
{
	public:
	void address(string ad){
			cout<<"city"<<endl;
		}
void address(int pincode){
			cout<<"pincode"<<endl;
		}


};
int main(){
   Student stu;
   stu.address("Goraya");
  stu.address(144416);
 
	
}


