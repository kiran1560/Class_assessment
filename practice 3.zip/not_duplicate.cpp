#include <iostream>

using namespace std;

void printWithoutDuplicates(int arr[], int size) {
    for (int i = 0; i < size; ++i) {
        bool isDuplicate = false;

       
        for (int j = 0; j < i; ++j) {
            if (arr[i] == arr[j]) {
                isDuplicate = true;
                break;
            }
        }

        if (!isDuplicate) {
            cout << arr[i] << " ";
        }
    }
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int *arr = new int[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    cout << "Array without duplicates: ";
    printWithoutDuplicates(arr, size);

    delete[] arr;

    return 0;
}

