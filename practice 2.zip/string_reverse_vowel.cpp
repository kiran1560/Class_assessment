#include <iostream>
#include <string>
#include <cctype>

using namespace std;

bool isVowel(char ch) {
    ch = tolower(ch);
    return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
}

int main() {
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    size_t i = 0, j = inputString.length() - 1;

    while (i < j) {
        // Find the next vowel from the beginning
        while (i < j && !isVowel(inputString[i])) {
            i++;
        }

        // Find the next vowel from the end
        while (i < j && !isVowel(inputString[j])) {
            j--;
        }

        // Swap the vowels
        if (i < j) {
            swap(inputString[i], inputString[j]);
            i++;
            j--;
        }
    }

    cout << "String with reversed vowels: " << inputString << endl;

    return 0;
}

