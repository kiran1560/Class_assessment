#include<iostream>
#include<fstream>
using namespace std;

namespace outer 
{
	int n=5;
	int arr[]={11,22,33,44,55};

	namespace inner //inner ns starts
	{
		void disp(int arr[], int n)
		{
			for(int i=0; i<n; i++)
			{
				cout<<arr[i]<<" ";
			}
		}
	}
	
	void print() //printing outer elementss
	{
	
	inner::disp(arr, n);
}
}

 
int main()
{
	//int num[]={1,2,3};
	//outer ::inner::disp(num,3); //calling outer->inner->displaying values of arr[]
	//cout<<endl;
	//outer::print();
	
outer ::inner::disp(outer :: arr,outer:: n);	 //2nd method

return 0;
}
