#include <iostream>

using namespace std;

void rightRotate(int arr[], int size, int rotations) {
    rotations = rotations % size; 
    reverse(arr, arr + size);

   reverse(arr, arr + rotations);


    reverse(arr + rotations, arr + size);
}

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int size = sizeof(arr) / sizeof(arr[0]);
    int rotations = 2; 

    cout << "Original array: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }

    rightRotate(arr, size, rotations);

    cout << "\nArray after right rotation: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
