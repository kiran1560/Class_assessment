#include <iostream>

using namespace std;

int main() {
    int n = 6;
    int array[] = {2, 4, 6, 1, 3, 5};
    int mid = n / 2;

    cout << "Given array: ";
    for (int i = 0; i < n; i++)
	{
        cout << array[i] << " ";
    }

    // Reverse the second half of the array
    int i = mid;
    int j = n - 1;
    while (i < j) 
	{
        swap(array[i], array[j]);
        i++;
        j--;
    }

    cout << "\n Array after reversing elements of the second half: ";
    for (int i = 0; i < n; i++) 
	{
        cout << array[i] << " ";
    }

    return 0;
}

