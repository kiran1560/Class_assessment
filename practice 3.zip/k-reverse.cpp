#include <iostream>

using namespace std;

int element(const int arr[], int size, int k) {
    if (k > 0 && k <= size) {
        return arr[size - k];
    } else {
        cout << "Invalid value of k. It should be in the range [1, " << size << "]\n";
        return -1; 
    }
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int k;
    cout << "Enter the value of k: ";
    cin >> k;

    int result = element(arr, size, k);

    if (result != -1) {
        cout << "The " << k << "-th element in reverse order is: " << result << endl;
    }

    return 0;
}

