#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main() {
    string inputString;
    cout << "Enter a string: ";
    getline(cin, inputString);

    int specialCharCount = 0;

    for (size_t i = 0; i < inputString.length(); ++i) {
        char ch = inputString[i];
        // Check if the character is a special character (not alphanumeric and not a space)
        if (!isalnum(ch) && !isspace(ch)) {
            specialCharCount++;
        }
    }

    cout << "Special characters (excluding spaces): " << specialCharCount << endl;

    return 0;
}

