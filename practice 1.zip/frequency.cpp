#include <iostream>
using namespace std;

int main() 
{   int n=7;
    int array[n] = {2, 2, 2, 4, 4, 5, 6};
    int s = sizeof(array) / sizeof(array[0]);
    int target;
    int frequency = 0;

cout << "Enter the number to find its frequency: ";
cin >> target;
    
    for (int i = 0; i < n; i++) {
        if (array[i] == target) 
		{
            frequency++;
        }
    }

    cout << "Frequency of " << target << ": " << frequency << "\n";

    return 0;
}

