#include <iostream>
#include <string>

using namespace std;

int main() {
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);


    for (size_t i = 0, j = inputString.length() - 1; i < j; ++i, --j) {
    
        char temp = inputString[i];
        inputString[i] = inputString[j];
        inputString[j] = temp;
    }

    cout << "Reversed string: " << inputString << endl;

    return 0;
}

