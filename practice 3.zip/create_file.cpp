#include <iostream>
#include <cstring>
using namespace std;

class Addition
{
	int a;
	int b;
	public:
	Addition(){
		a=0;
		b=0;
	}


	Addition(int x,int y)
	{
		a=x;
		b=y;
	}
	
	void disp(){
		cout<<a<<" "<<b;
	}
	Addition operator +(Addition &obj)
	{
		Addition add;
		add.a=a+obj.a;
		add.b=b+obj.b;
		return add;
	}
};
int main(){
	Addition a1(20,30),a2(20,50);
	Addition a3=a1+a2;
	a3.disp();
	return 0;
	
}
