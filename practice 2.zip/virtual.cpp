#include<iostream>
using namespace std;
class FacebookOld
{
	public:
		virtual void reaction() //virtual keyword for deriving properties of base class into the derived class
		{
			cout<<"like"<<endl;
		}
};
class FacebookNew: public FacebookOld
{
	public:
		void reaction()
		{
			cout<<"like funny angry sad cry"<<endl;
		}
};
int main(){
	FacebookNew fb;
	
	FacebookOld *f =&fb;
	
	f->reaction(); //cant use dot operator, only use arrow operator
	
}
