#include <iostream>
#include <string>

bool isConsonant(char ch) {
    return isalpha(ch) && !((ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U'));
}

int countConsonants(const std::string& str) {
    int count = 0;

    for (size_t i = 0; i < str.length(); ++i) {
        if (isConsonant(str[i])) {
            count++;
        }
    }

    return count;
}

int main() {
    std::string str;

    std::cout << "Enter a string: ";
    std::getline(std::cin, str);

    int consonantCount = countConsonants(str);

    std::cout << "Number of consonants in the string: " << consonantCount << std::endl;

    return 0;
}

