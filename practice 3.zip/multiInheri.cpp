#include <iostream>
using namespace std;

class School
{
  public:  
void MarksOld(){
	cout<<"old marks";
}
	
};
//derived class

class Classroom : public School{
	public:
void MarksNew(){
	cout<<"new marks";
}
};

class Classroom2 : public Classroom{
public:
void MarksAdd(){
	cout<<"add marks";
}

};
	

int main(){
	
Classroom sl;
sl.MarksOld();    
 sl.MarksNew(); 
 //sl.MarksAdd(); 
      
   return 0;
}
