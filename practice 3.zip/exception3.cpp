#include<iostream>
//#include<exception>
#include<stdexcept>
using namespace std;
int main()
{
	
	cout<<"start \n";
	//int a=10, b=0;
	
	try{
		int *arr=new int[1000];
	}
		                              
	catch(exception &e) 
	{
		cout<<"std exception: ";
		cout<<e.what();		
	}
	
	cout<<"\n end \n";
	return 0;
}
