#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main() {
    string inputString;
    cout << "Enter a string: ";
    getline(cin, inputString);

    int vowelCount = 0;
    int consonantCount = 0;

    for (size_t i = 0; i < inputString.length(); ++i) {
        // Convert the character to lowercase for case-insensitive comparison
        char lowercaseCh = tolower(inputString[i]);

        // Check if the character is a vowel
        if (lowercaseCh == 'a' || lowercaseCh == 'e' || lowercaseCh == 'i' || lowercaseCh == 'o' || lowercaseCh == 'u') {
            vowelCount++;
        }
        // Check if the character is a consonant
        else if (isalpha(lowercaseCh)) {
            consonantCount++;
        }
    }

    cout << "Vowels: " << vowelCount << endl;
    cout << "Consonants: " << consonantCount << endl;

    return 0;
}

