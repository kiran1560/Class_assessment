#include<iostream>
using namespace std;
class FacebookOld
{
	public:
		virtual void reaction()=0; //abstract class, having pure virtual
};
class FacebookNew: public FacebookOld
{
	public:
		void reaction()
		{
			cout<<"like funny angry sad cry"<<endl;
		}
};
class FacebookNew2: public FacebookOld
{
	public:
		void reaction()
		{
			cout<<"like funny angry sad cry laugh bird"<<endl;
		}
};
int main(){
	FacebookNew fb;
	FacebookNew2 fb2;
	
	FacebookOld *f =&fb; 
	FacebookOld *f2 =new FacebookNew2; //dynamic memory allocation
	
	f->reaction(); //cant use dot operator, only use arrow operator
	f2->reaction();
}

//example of data abstraction is power function in math.h
