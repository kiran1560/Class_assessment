#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char a[50];
    cin>>a;
    
   int n=strlen(a);
   for(int i=0;i<n;i++)
   {
   	if(a[i]>=97 && a[i]<=122)  
   	{
   		a[i]=a[i]-32; 
	  // a[i]=a[i]|+32;  //for lowercase
	   } 
   }
    
     
	 	cout<<a;

    return 0;
}

