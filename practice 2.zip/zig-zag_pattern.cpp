#include <iostream>
using namespace std;

void zigZag(int rows, int cols) {
    int matrix[rows][cols];

    int num = 1;
    for (int i = 0; i < rows; i++) 
	{
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = num++;
        }
    }
    for (int i = 0; i < rows; i++) 
	{
        if (i % 2 == 0) 
		{
            for (int j = 0; j < cols; j++) 
			{
                cout << matrix[i][j] << " ";
            }
        } else 
		{
            for (int j = cols - 1; j >= 0; --j) 
			{
                cout << matrix[i][j] << " ";
            }
        }
    }
}

int main() {
    int rows, cols;

    cout << "Enter the number of rows: ";
    cin >> rows;

    cout << "Enter the number of columns: ";
    cin >> cols;

    cout << "Number-based Zig-Zag Pattern:" << endl;
    zigZag(rows, cols);

    return 0;
}

