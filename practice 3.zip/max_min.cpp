#include <iostream>

using namespace std;

void findMaxElementAndIndex(int arr[], int size, int& maxElement, int& maxIndex) {
    if (size == 0) {
        cerr << "Error: Empty array\n";
        maxElement = -1; 
        maxIndex = -1;
        return;
    }

    maxElement = arr[0];
    maxIndex = 0;

    for (int i = 1; i < size; ++i) {
        if (arr[i] > maxElement) {
            maxElement = arr[i];
            maxIndex = i;
        }
    }
}

int main() {
    int arr[] = {5, 2, 8, 1, 6};
    int size = sizeof(arr) / sizeof(arr[0]);

    int maxElement, maxIndex;
    findMaxElementAndIndex(arr, size, maxElement, maxIndex);

    cout << "Maximum element in the array: " << maxElement << endl;
    cout << "Index of the maximum element: " << maxIndex << endl;

    return 0;
}
