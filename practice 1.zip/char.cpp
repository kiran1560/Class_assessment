#include <iostream>
using namespace std;

int main() {
    char arr[10];
    cin.getline(arr,10); //syntax for char
    cout<<arr;

    return 0;
}

