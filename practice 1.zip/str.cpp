#include <iostream>
#include <cstring>
using namespace std;

struct student
{
	int rollno;
	char name[50];
	float avg;
	int m1,m2,m3;
};

int main() {
   student s[60];
   for(int i=1;i<=3;i++)
   {
   	cout<<"roll no: "<<i<<endl;
   	cin>>s[i].name;
   	
   	cout<<" enter marks: "<<endl;
   	cin>>s[i].m1>>s[i].m2>>s[i].m3;
   	
   	cout<<" marks of students: "<<endl;
   	cout<<s[i].m1<<" "<<s[i].m2<<" "<<s[i].m3<<endl;
   	s[i].avg=(s[i].m1+s[i].m2+s[i].m3)/3;
   	cout<<s[i].avg<<endl;
   	
   	
   }
    return 0;
}

