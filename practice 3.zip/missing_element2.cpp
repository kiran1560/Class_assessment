#include <iostream>

using namespace std;

int findMinElement(int arr[], int size) {
    if (size == 0) {
        cerr << "Error: Empty array\n";
        return -1; 
    }

    int minElement = arr[0];
    for (int i = 1; i < size; ++i) {
        if (arr[i] < minElement) {
            minElement = arr[i];
        }
    }

    return minElement;
}

int main() {
    int arr[] = {5, 2, 8, 1, 6};
    int size = sizeof(arr) / sizeof(arr[0]);

    int minElement = findMinElement(arr, size);

    cout << "Minimum element in the array: " << minElement << endl;

    return 0;
}

