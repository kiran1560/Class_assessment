#include <iostream>
#include <string>
#include <cctype>

using namespace std;

bool isVowel(char ch) {
    ch = tolower(ch);
    return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
}

int main() {
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    for (size_t i = 0; i < inputString.length(); ++i) {
        if (isVowel(inputString[i])) {
            inputString[i] = '$';
        }
    }

    cout << "String with vowels replaced: " << inputString << endl;

    return 0;
}

