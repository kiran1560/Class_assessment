#include <iostream>
#include <cstring>
using namespace std;

bool isStrongPassword(string password)
{
    bool containsUppercase = false;
    bool containsDigits = false;
    bool containsSpecials = false;

    for (size_t i = 0; i < password.size(); ++i)
    {
        char c = password[i];

        if (isupper(c))
        {
            containsUppercase = true;
        }
        if (isdigit(c))
        {
            containsDigits = true;
        }
        if (ispunct(c))
        {
            containsSpecials = true;
        }
    }

    if (containsUppercase && containsDigits && containsSpecials && password.size() >= 8)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    string password;

    cout << "Enter password: ";
    getline(cin, password);

    if (isStrongPassword(password))
    {
        cout << "Strong" << endl;
    }
    else
    {
        cout << "Not Strong" << endl;
    }

    return 0;
}

