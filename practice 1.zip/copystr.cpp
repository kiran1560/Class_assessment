#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char a[50]="toy";
    char b[50];
    
     
    strcpy(b,a);
	 	cout<<"string for b: "<<b;

    return 0;
}

