#include <iostream>

using namespace std;

void selectionSort(int arr[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < size; ++j) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
 
        int temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}

void alternateSort(int arr[], int size) {
    selectionSort(arr, size);

    int* result = new int[size];
    int left = 0, right = size - 1;

    for (int i = 0; i < size; ++i) {
        if (i % 2 == 0) {
            result[i] = arr[left++];
        } else {
            result[i] = arr[right--];
        }
    }

    for (int i = 0; i < size; ++i) {
        arr[i] = result[i];
    }

    delete[] result;
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int* arr = new int[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    alternateSort(arr, size);

    cout << "Array after alternate sort: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }

    delete[] arr;

    return 0;
}

