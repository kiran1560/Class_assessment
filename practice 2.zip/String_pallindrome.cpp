#include<iostream>
#include<cstring>
using namespace std;

int main() {
    string str;
    
    cout << "Enter string: ";
    getline(cin, str);
    cout << "String is: " << str << endl;

    int l=0;
    int h=str.length()- 1;

    while (h>l) {
        if (str[l++] == str[h--]) {
            cout << " a palindrome" << endl;
            return 0;
        }
    }

    cout << "is not a palindrome" << endl;

    return 0;
}

