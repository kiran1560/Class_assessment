#include <iostream>
#include <algorithm>

using namespace std;

int kthMaxElement(int arr[], int size, int k) {
    if (k > 0 && k <= size) {
        sort(arr, arr + size, greater<int>());
        return arr[k - 1];
    } else {
        cerr << "Error: Invalid value of k\n";
        return -1; 
    }
}

int main() {
    int arr[] = {5, 2, 8, 1, 6};
    int size = sizeof(arr) / sizeof(arr[0]);
    int k = 3;

    int kthMax = kthMaxElement(arr, size, k);

    if (kthMax != -1) {
        cout << "The " << k << "th maximum element in the array is: " << kthMax << endl;
    }

    return 0;
}

