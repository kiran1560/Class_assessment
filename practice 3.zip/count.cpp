#include<iostream>
#include<string>
using namespace std;

class occurance{
public:
 virtual void countOccurrence()
{ 
int count=0;
cout<<"Occurance of the character: "<<endl;
}
};

class derived : public occurance
{
public:
void countOccurrence()
{

string str;
char target='k';

cout<<"Enter the string: " <<endl;
getline(cin, str);
for (int i=0; i<str.length(); i++) 
{
 if(str[i]==target) 
{
    count++;
}
    } };
        
int main()
{
derived d;
occurance *o =&d;
o->countOccurrence();

cout << "The character " <<target<< "occurs "<<count<< " times"<< endl;
return 0;

}
