#include <iostream>

using namespace std;

int reverse(int num) {
    int result = 0;
    
    while (num != 0) {
        int digit = num % 10;
        result = result * 10 + digit;
        num /= 10;
    }
    
    return result;
}

int main() {
    int number;

    cout << "Enter a number: ";
    cin >> number;
    int reversedNumber = reverse(number);

    
    cout << "Reversed number: " << reversedNumber << endl;

    return 0;
}

