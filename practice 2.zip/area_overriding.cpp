#include<iostream>
using namespace std;
class Shape
{
	public:
		virtual void area() //virtual keyword for deriving properties of base class into the derived class
		{
			cout<<"rectangle and triangle"<<endl;
		}
};
class rectangle: public Shape
{
	public:
		void area()
		{
			int b,h;
			area= b*h;
			cout<<"area of rectangle"<<b<<h<<area<<endl;
		}
};
class triangle: public Shape
{
	public:
		void area()
		{
			int b,h;
			area= (b*h)/2;
			cout<<"area of rectangle"<<b<<h<<area<<endl;
		}
};

int main(){
	
	rectangle r;
	triangle t;
	
	Shape *s1 =&r;
	Shape *s2 =&t;
	
	s1->area(); //cant use dot operator, only use arrow operator
	s2->area();
	
	return 0;
}
