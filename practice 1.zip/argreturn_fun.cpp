#include <iostream>

using namespace std;

int fun(int x, int y) //with argument 
{
	if(x>y)
return x;  //with return 
	else
return y;
}
int main()
{
	int x;
	int y;
	cin>>x>>y;
	cout<<fun(x,y); 
    return 0;
}


