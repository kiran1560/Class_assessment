#include <iostream>

using namespace std;

int main() {
    int size;
    cout << "Enter the size of the arrays: ";
    cin >> size;

    int arr1[size];
    int arr2[size];

    cout << "Enter the elements of the first array: ";
    for (int i = 0; i < size; ++i) {
        cin >> arr1[i];
    }

    cout << "Enter the elements of the second array (with an extra element): ";
    for (int i = 0; i < size; ++i) {
        cin >> arr2[i];
    }

  
    int extraElement = -1;
    int extraIndex = -1;

    for (int i = 0; i < size; ++i) {
        if (arr1[i] != arr2[i]) {
            extraElement = arr2[i];
            extraIndex = i;
            break;
        }
    }

    if (extraIndex != -1) {
        cout << "Extra element: " << extraElement << endl;
        cout << "Index of the extra element: " << extraIndex << endl;
    } else {
        cout << "No extra element found." << endl;
    }

    return 0;
}


