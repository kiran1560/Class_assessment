#include <iostream>

using namespace std;

int fun() //no argument 
{
	int x,y;
	cin>>x>>y;
	if(x>y)
	return x; //with return
	else
	return y;
}
int main()
{
	cout<<fun(); 
    return 0;
}


