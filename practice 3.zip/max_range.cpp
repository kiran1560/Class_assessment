#include <iostream>

using namespace std;

int findMaxInRange(const int arr[], int start, int end) {
    if (start < 0 || end >= 0) {
        cout << "Invalid range.\n";
        return -1; // Return -1 to indicate an error
    }

    int maxElement = arr[start];

    for (int i = start + 1; i <= end; ++i) {
        if (arr[i] > maxElement) {
            maxElement = arr[i];
        }
    }

    return maxElement;
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int start, end;
    cout << "Enter the range (start and end indices): ";
    cin >> start >> end;

    int result = findMaxInRange(arr, start, end);

    if (result != -1) {
        cout << "The maximum element in the specified range is: " << result << endl;
    }

    return 0;
}
