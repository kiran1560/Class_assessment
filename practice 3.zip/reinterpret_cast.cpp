#include<iostream>
#include<fstream>
using namespace std;
int main()
{
int *ptr=new int(65);
char *ch=reinterpret_cast<char *>(ptr);
cout<<ch;
return 0;
}
