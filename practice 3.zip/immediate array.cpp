#include <iostream>

using namespace std;

void immediate(const int arr[], int size) {
    cout << "Immediate greater element for each element:\n";

    for (int i = 0; i < size - 1; ++i) {
        int immediateGreater = -1;

        for (int j = i + 1; j < size; ++j) {
            if (arr[j] > arr[i]) {
                immediateGreater = arr[j];
                break;
            }
        }

        cout << arr[i] << ": " << (immediateGreater != -1 ? to_string(immediateGreater) : "No greater element") << endl;
    }

    cout << arr[size - 1] << ": No greater element" << endl;
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    immediate(arr, size);

    return 0;
}

