#include <iostream>
#include <cstring>
using namespace std;

int main()
 {
    char a[50];
    cin>>a;
    int n=strlen(a);
  
    
    for(int i=0;i<n;i++)
     {
    int count=0;
     for(int j=0;j<n;j++)
     
	 { 
	 if(a[i]==a[j])
	 {
	 count++;
		 }
		 }
		 if (count==1)
	{
		 cout<<a[i];
		/// break;	
			 	}
	 }
   

