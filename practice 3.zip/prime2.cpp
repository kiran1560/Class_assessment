#include <iostream>
#include <cmath>

using namespace std;

bool isPrime(int num) {
    if (num <= 1) {
        return false;
    }

    for (int i = 2; i <= sqrt(num); ++i) {
        if (num % i == 0) {
            return false;
        }
    }

    return true;
}

int findLeastPrime(const int arr[], int size) {
    int leastPrime = -1;

    for (int i = 0; i < size; ++i) {
        if (isPrime(arr[i])) {
            if (leastPrime == -1 || arr[i] < leastPrime) {
                leastPrime = arr[i];
            }
        }
    }

    return leastPrime;
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int result = findLeastPrime(arr, size);

    if (result != -1) {
        cout << "The least prime number in the array is: " << result << endl;
    } else {
        cout << "No prime numbers found in the array.\n";
    }

    return 0;
}

