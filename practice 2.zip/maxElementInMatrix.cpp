#include <iostream>
using namespace std;

const int N = 4;
void printArray(int result[], int rows) {
    for (int i = 0; i < rows; i++)
	 {
        cout << result[i] << endl;
    }
}

void maxElement(int rows, int arr[][N])
 {
    int i = 0;
    int max = 0;
    int result[rows];
    while (i < rows)
	 {
        for (int j = 0; j < N; j++) 
		{
            if (arr[i][j] > max) 
			{
                max = arr[i][j];
            }
        }
        result[i] = max;
        max = 0;
        i++;
    }
    printArray(result, rows);
}

int main() {
    int arr[][N] = {{3, 4, 1, 8},
                    {1, 4, 9, 11},
                    {76, 34, 21, 1},
                    {2, 1, 4, 5}};

    maxElement(4, arr);

    return 0;
}

