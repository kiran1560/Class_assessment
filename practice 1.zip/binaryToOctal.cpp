#include <iostream>
#include <cmath>
using namespace std;

// Function to convert binary to decimal
int binaryToDecimal(int binary)
{
    int decimal = 0, base = 0;
    while (binary != 0)
    {
        int last_digit = binary % 10;
        binary /= 10;
        decimal += last_digit * pow(2, base);
        ++base;
    }
    return decimal;
}

// Function to convert decimal to octal
int decimalToOctal(int decimal)
{
    int octal = 0, base = 1;
    while (decimal != 0)
    {
        octal += (decimal % 8) * base;
        decimal /= 8;
        base *= 10;
    }
    return octal;
}

// Function to convert binary to octal
int binaryToOctal(int binary)
{
    int decimal = binaryToDecimal(binary);
    int octal = decimalToOctal(decimal);
    return octal;
}

int main()
{
    int binaryNumber;

    cout << "Enter a binary number: ";
    cin >> binaryNumber;

    int octalNumber = binaryToOctal(binaryNumber);

    cout << "Octal equivalent: " << octalNumber << endl;

    return 0;
}

