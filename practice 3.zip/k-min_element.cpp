#include <iostream>

using namespace std;

void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

void selectionSort(int arr[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < size; ++j) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        swap(arr[i], arr[minIndex]);
    }
}

int kthMinElement(int arr[], int size, int k) {
    if (k > 0 && k <= size) {
        selectionSort(arr, size);
        return arr[k - 1];
    } else {
        cerr << "Error: Invalid value of k\n";
        return -1; 
    }
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int *arr = new int[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int k;
    cout << "Enter the value of k: ";
    cin >> k;

    int kthMin = kthMinElement(arr, size, k);

    if (kthMin != -1) {
        cout << "The " << k << "th minimum element in the array is: " << kthMin << endl;
    }

    delete[] arr;

    return 0;
}
