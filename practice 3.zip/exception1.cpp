#include<iostream>
using namespace std;
int main()
{
	
	cout<<"start \n";
	int a=10, b=0;
	
	try{
		if(b==0)
		  {
			throw "cant divide by 0 \n"; //throw 0;
		  } 
			cout<<a/b;
	}
		                              
	catch(const char *e) //catch(...)       ,   for no specific datatype
	{
		cout<<"exception occured: "<<e;		
	}
	
	cout<<"\n end \n";
	return 0;
}
