#include <iostream>

using namespace std;
class Amazon
{
	public:
	void payment(){
			cout<<"Cashon delivery"<<endl;
		}
	void payment(long int card){
			cout<<"Card payment"<<endl;
		}
	void payment(string s){
			cout<<"UPI payment"<<endl;
		}
    void payment(string bank, int otp){
			cout<<"net banking"<<endl;
		}


};
int main(){
	Amazon a;
   a.payment();
  a.payment(123456789);
  a.payment("payment");
  a.payment("SBSbanking", 5687);
	
}


