#include <iostream>
using namespace std;

void floyyd(int row) {
    int count = 1;

    for (int i = 1; i <= row; i++) 
	{
        for (int k = 1; k <= row - i; k++) {
            cout << "  ";
        }
        
        for (int j = 1; j <= i; j++) {
            cout << count++ << " ";
        }

        cout << "\n";
    }
}

int main() {
    int row = 5;
    floyyd(row);

    return 0;
}

