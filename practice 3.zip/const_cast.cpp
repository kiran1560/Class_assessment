#include<iostream>
#include<fstream>
using namespace std;
int main()
{
const int val=50;
int *mulptr= const_cast<int*>(&val);
*mulptr=70;
cout<<*mulptr;

return 0;
}
