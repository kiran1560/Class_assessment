#include<iostream>
using namespace std;
class Base
{
	public:
		virtual void disp()
		{
			cout<<"base class"<<endl;
		}
};
class Derived: public Base
{
	public:
		void disp()
		{
			cout<<"derived class"<<endl;
		}
};
int main(){
	Derived d;
	Base *b =&d;
	b->disp();
	
}
