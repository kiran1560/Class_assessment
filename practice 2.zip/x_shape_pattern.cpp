#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the size of the pattern: ";
    cin >> n;

    // Print the upper part of the X pattern
    for (int i = 0; i < n; i++) 
	{
        for (int j = 0; j < n; j++) 
		{
            if (i == j || i + j == n - 1)
                cout << "X";
            else
                cout << " ";
        }
        cout << endl;
    }

    // Print the lower part of the X pattern
    for (int i = n - 2; i >= 0; i--) 
	{
        for (int j = 0; j < n; j++) 
		{
            if (i == j || i + j == n - 1)
                cout << "*";
            else
                cout << " ";
        }
        cout << endl;
    }

    return 0;
}

