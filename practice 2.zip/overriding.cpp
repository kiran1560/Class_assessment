#include<iostream>
using namespace std;


class Developer  {
	public:
		void post(){
			cout<<"developer: "<<endl;
		}
};

class Coder: public Developer  {
	public:
		void post(){
			cout<<" developer to coder: "<<endl;
		}
};

class Tester: public Developer  {
	public:
		void post(){
			cout<<"developer to tester: "<<endl;
		}
};
class TesterModule1: public Tester  {
	public:
		void post(){
			cout<<"tester to tester 1: "<<endl;
		}
};
class TesterModule2: public Tester  {
	public:
		void post(){
			cout<<"tester to tester 2: "<<endl;
		}
};

class Coder1: public Coder  {
	public:
		void post(){
			cout<<"coder to coder1: "<<endl;
		}
};
class Coder2: public Coder  {
	public:
		void post(){
			cout<<"coder to coder2: "<<endl;
		}
};

int main(){
	Tester t;
	Coder cd;
	
	TesterModule1 t1;
	TesterModule2 t2;
	Coder1 cd1;
	Coder2 cd2;
	
	Developer *d1=&t;
	Developer *d2=&cd;
	
	Tester *d3=&t1;
	Tester *d4=&t2;
	Coder *d5=&cd1;
	Coder *d6=&cd2;
	
	d1->post();
	d2->post();
	d3->post();
	d4->post();
	d5->post();
	d6->post();
	
	
}
