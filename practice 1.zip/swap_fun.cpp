#include <iostream>

using namespace std;
int fun(int x, int y) //with argument 
{
	int x =temp;
	temp= int y;
	x=y;
	return x;
	return y;
}
int main()
{
	int x;
	int y;
	cin>>x>>y;
	cout<<fun(x,y); 
    return 0;
}


