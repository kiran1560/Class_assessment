#include <iostream>

using namespace std;
class Engine
{
	public:
		void power()
		{
			cout<<"Engine power"<<endl;
		}
};
class Car
{
	public:
		Engine e;
		void start()
		{
			e.power()
		cout<<"car started"<<endl;
		}
};
int main()
{
	Car kia;
	kia.start();
}
    return 0;
}


