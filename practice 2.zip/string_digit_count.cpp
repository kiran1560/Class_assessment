#include <iostream>
#include <string>

using namespace std;

int main() {
    string inputString;
    cout << "Enter a string: ";
    getline(cin, inputString);

    int digitCount = 0;

    for (size_t i = 0; i < inputString.length(); ++i) {
        char ch = inputString[i];
        if (isdigit(ch)) {
            digitCount++;
        }
    }

    cout << "Number of digits in the string: " << digitCount << endl;

    return 0;
}

