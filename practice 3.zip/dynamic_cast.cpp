#include<iostream>
#include<fstream>
using namespace std;

class Base {
	virtual void message()=0;
};

class Derived: public Base{
	void message() override
	{
		cout<<"Derived class";
	}
};



int main()
{
Base *ptr=new Derived;
Derived *dp= dynamic_cast<Derived*>(ptr); //convert base type to dynamic type

if(dp!=NULL)
{
	cout<<"dynamic success:";
	
}
else
{
	cout<<"failed";
}
delete ptr;

return 0;
}
