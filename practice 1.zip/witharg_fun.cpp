#include <iostream>

using namespace std;

int fun(int x, int y) //with argument 
{
	if(x>y)
cout<<"x"; //no return
	else
	cout<<"y";
}
int main()
{
	int x;
	int y;
	cin>>x>>y;
	fun(x,y); 
    return 0;
}


