#include <iostream>
#include <cstring>
using namespace std;

int main() {
    string s;
    getline(cin,s);
	
	
	for (int i = 0; i<s; i++) 
	{
        swap(array[i], array[s - 1 - i]);
    }

   ;
    for (int i = 0; i < n; i++) {
        cout << array[i] << " ";
    }

    return 0;
}


