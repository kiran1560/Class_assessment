#include <iostream>

using namespace std;
class Facebook
{
	public:
	void login(int a, string p){
			cout<<"phone no. login"<<endl;
		}
	void login(string s, string p){
			cout<<"user name login"<<endl;
		}
   


};
int main(){
   Facebook fb;
 fb.login(5664443228, "kiran");
 fb.login("Kiran16", "kiran");
	
}


