#include <iostream>
#include <string>

using namespace std;

int main() {
    string str;

    cout << "Enter a string: ";
    getline(cin, str);

    int sum = 0;

    for (size_t i = 0; i <str.length(); i++)
	 {
        char ch = str[i];
        sum += ch;
    }

    cout << "Sum of ASCII values: " << sum << endl;

    return 0;
}

