#include <iostream>
#include <string>

using namespace std;

int main() {
    string str;
    
    char targetChar = 'l';

    cout << "Enter a string: ";
    getline(cin, str);

    int count = 0;
    for (size_t i = 0; i < str.length(); i++) {
        if (str[i] == targetChar) {
            count++;
        }
    }
    cout << "The character '" << targetChar << "' occurs " << count << " times in the string." << endl;

    return 0;
}



