#include <iostream>
#include <cmath>
using namespace std;

// Function to convert binary to decimal
int binaryToDecimal(int n)
{
    int num = n;
    int dec_value = 0;
    int base = 0;

    // Count the number of digits in the binary number
    int temp = num;
    while (temp)
    {
        temp = temp / 10;
        base++;
    }

    // Reset temp to the original binary number
    temp = num;

    // Calculate decimal value
    while (temp)
    {
        int last_digit = temp % 10;
        temp = temp / 10;

        dec_value += last_digit * pow(2, base - 1);

        base--;
    }

    return dec_value;
}

// Driver program to test above function
int main()
{
    int num;

    cout << "Enter a binary number: ";
    cin >> num;

    cout << "Decimal equivalent: " << binaryToDecimal(num) << endl;

    return 0;
}

