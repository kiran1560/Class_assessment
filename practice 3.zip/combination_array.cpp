#include <iostream>

using namespace std;

void printCombination(int combination[], int length) {
    cout << "Combination: ";
    for (int i = 0; i < length; ++i) {
        cout << combination[i] << " ";
    }
    cout << endl;
}

void findCombinations(int arr[], int target, int combination[], int currentSize, int currentIndex) {
    if (target == 0) {
        printCombination(combination, currentSize);
        return;
    }

    for (int i = currentIndex; i < currentSize; ++i) {
        if (target - arr[i] >= 0) {
            combination[currentSize] = arr[i];
            findCombinations(arr, target - arr[i], combination, currentSize + 1, i);
        }
    }
}

void printAllCombinations(int arr[], int size, int target) {
    int combination[size];
    findCombinations(arr, target, combination, 0, 0);
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) 
	{
        cin >> arr[i];
    }}
    
