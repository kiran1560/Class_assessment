#include <iostream>
#include <cstring>
using namespace std;

int main(){
	int a;
	cin>>a;
	int b=a*a;
	cout<<b<<endl;
	int flag=0,x,y;
	
	while(a!=0 && b!=0)
	{
		x=a%10;
		y=b%10;
		
		if(x!=y)
		{
			flag=1;
			break;
		}
		a=a/10;
		b=b/10;
	}
	
	if(flag ==0)
	{
		cout<<"auromorphic"<<endl;
	}
	else
{
	cout<<"not";
}
}

//flag based
