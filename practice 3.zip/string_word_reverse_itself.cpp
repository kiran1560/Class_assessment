#include <iostream>
#include <string>

using namespace std;

int main() {
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    string reversedString;
    string currentWord;

    for (size_t i = 0; i < inputString.length(); ++i) {
        char ch = inputString[i];

        if (isspace(ch)) {
          
            for (size_t j = 0, k = currentWord.length() - 1; j < k; ++j, --k) {
                swap(currentWord[j], currentWord[k]);
            }
            reversedString += currentWord + " ";
            currentWord.clear();
        } else {
            currentWord += ch;
        }
    }

    for (size_t i = 0, j = currentWord.length() - 1; i < j; ++i, --j) {
        swap(currentWord[i], currentWord[j]);
    }
    reversedString += currentWord;

    cout << "Reversed string: " << reversedString << endl;

    return 0;
}

