#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main() {
    string inputString;
    cout << "Enter a string: ";
    getline(cin, inputString);

    int wordCount = 0;
    bool inWord = false;

    for (size_t i = 0; i < inputString.length(); ++i) {
        char ch = inputString[i];

        // Check if the character is whitespace
        if (isspace(ch)) {
            inWord = false;  // Transition to non-word state
        } else {
            // Check if we are at the beginning of a new word
            if (!inWord) {
                inWord = true;  // Transition to word state
                wordCount++;
            }
        }
    }

    cout << "Word count: " << wordCount << endl;

    return 0;
}

