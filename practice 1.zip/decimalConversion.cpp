#include <iostream>
#include <cmath>
using namespace std;

// Function to convert decimal to binary
long long decimalToBinary(int decimal)
{
    long long binary = 0;
    int base = 1;
    while (decimal > 0)
    {
        binary += (decimal % 2) * base;
        decimal /= 2;
        base *= 10;
    }
    return binary;
}

// Function to convert decimal to octal
int decimalToOctal(int decimal)
{
    int octal = 0, base = 1;
    while (decimal > 0)
    {
        octal += (decimal % 8) * base;
        decimal /= 8;
        base *= 10;
    }
    return octal;
}

// Function to convert decimal to hexadecimal
string decimalToHexadecimal(int decimal)
{
    string hexadecimal = "";
    while (decimal > 0)
    {
        int remainder = decimal % 16;
        if (remainder < 10)
            hexadecimal = char(remainder + '0') + hexadecimal;
        else
            hexadecimal = char(remainder - 10 + 'A') + hexadecimal;

        decimal /= 16;
    }
    return hexadecimal;
}

int main()
{
    int decimalNumber;

    cout << "Enter a decimal number: ";
    cin >> decimalNumber;

    cout << "Binary equivalent: " << decimalToBinary(decimalNumber) << endl;
    cout << "Octal equivalent: " << decimalToOctal(decimalNumber) << endl;
    cout << "Hexadecimal equivalent: " << decimalToHexadecimal(decimalNumber) << endl;

    return 0;
}

