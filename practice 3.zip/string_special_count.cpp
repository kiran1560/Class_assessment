#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main() {
    string str;
    cout << "Enter a string: ";
    getline(cin, str);

    int specialCharCount = 0;

    for (size_t i = 0; i < str.length(); ++i) {
        // Check if the character is a special character (not alphanumeric)
        if (!isalnum(str[i])) {
            specialCharCount++;
        }
    }

    cout << "Special characters: " << specialCharCount << endl;

    return 0;
}

