#include <iostream>
#include <string>
#include <cctype>

using namespace std;

bool isPalindrome(const string& str) {
    size_t i = 0;
    size_t j = str.length() - 1;

    while (i < j) {
        // Ignore non-alphanumeric characters from the beginning
        while (i < j && !isalnum(str[i])) {
            i++;
        }

        // Ignore non-alphanumeric characters from the end
        while (i < j && !isalnum(str[j])) {
            j--;
        }

        // Compare characters (case-insensitive)
        if (tolower(str[i]) != tolower(str[j])) {
            return false; // Not a palindrome
        }

        i++;
        j--;
    }

    return true; // Palindrome
}

int main() {
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    if (isPalindrome(inputString)) {
        cout << "The string is a palindrome." << endl;
    } else {
        cout << "The string is not a palindrome." << endl;
    }

    return 0;
}

