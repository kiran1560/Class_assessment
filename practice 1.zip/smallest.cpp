#include <iostream>
using namespace std;

int main() 
{
    const int n = 7; 
    int arr[n] = {11, 2, 6, 3, 9, 1, 5};

    int firstSmallest = arr[0];
    int secondSmallest = arr[1];

    if (secondSmallest < firstSmallest) 
	{
        swap(firstSmallest, secondSmallest);
    }

    for (int i = 2; i < n; ++i) {
        if (arr[i] < firstSmallest)
		 {
            secondSmallest =firstSmallest;
            firstSmallest = arr[i];
        } 
		else if (arr[i] < secondSmallest && arr[i] != firstSmallest)
		 {
            secondSmallest = arr[i];
        }
    }

    cout << "First Smallest number: " << firstSmallest<<endl;
    cout << "Second Smallest number: " << secondSmallest;

    return 0;
}

