#include <iostream> 
#include<cstring>
using namespace std; 
 
bool isConsonant(char ch) 
{  
    ch=toupper(ch); 
    return !(ch == 'A' || ch == 'E' ||  ch == 'I' || ch == 'O' || ch == 'U') && ch >= 65 && ch <= 90; 
} 
int consonants(string str) 
{ 
    int count=0; 
    for (int i = 0; i < str.length(); i++)   
        if (isConsonant(str[i])) 
            count++; 
    return count; 
} 
int main() 
{ 
    string str = "Laptop charger"; 
    cout << consonants(str); 
    return 0; 
} 
