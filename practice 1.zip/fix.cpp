#include <iostream>
#include <cstring>
using namespace std;

int main(){
    int a = 2, b = 3, c = 1, d = 4, e = 5, f = 2; // Assign some values to the variables

    if((a * b) > (c * d) && (a * b) > (e * f))
    {
        cout << "fix" << endl;
    }
    else
    {
        cout << "cant fix" << endl;
    }

    return 0;
}

