#include<iostream>
using namespace std;
class Whatsapp
{
	public:
		virtual void report() //virtual keyword for deriving properties of base class into the derived class
		{
			cout<<"sent"<<endl;
		}
};
class Whatsapp1: public Whatsapp
{
	public:
		void report()
		{
			cout<<"sent-delivered"<<endl;
		}
};
class Whatsapp2: public Whatsapp
{
	public:
		void report()
		{
			cout<<"sent-seen"<<endl;
		}
};
int main(){
	Whatsapp1 w1;
	Whatsapp2 w2;
	
	Whatsapp *w11 =&w1;
	Whatsapp *w12 =&w2;
	
	w11->report(); //cant use dot operator, only use arrow operator
	w12->report();
}
