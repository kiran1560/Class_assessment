#include <iostream>

using namespace std;

void fun() //no argument 
{
	int x,y;
	cin>>x>>y;
	if(x>y)
	cout<<"x is greater: ";
	else
	cout<<"x is greater: ";
}
int main()
{
	fun(); //no return
    return 0;
}


