#include <iostream>

using namespace std;
class construct
{
	public:
		float area;
		construct(){
			cout<<"0 arg"<<endl;
			area =0;
		}
		construct(int a, int b)
		{
			cout<<"2 arg"<<endl;
			area =a*b;
		}
		void disp(){
			cout<<area<<endl;
		}
   


};
int main(){
   construct o;
   
 o.disp();
 construct o2(10,40);
 o2.disp();
 return 0;
	
}

//constructor overloading


