#include <iostream>
using namespace std;

int main() 
{
    const int n = 7; 
    int arr[n] = {11, 2, 6, 3, 9, 1, 5};

    int firstLargest = arr[0];
    int secondLargest = arr[1];

    if (secondLargest > firstLargest) 
	{
        swap(firstLargest, secondLargest);
    }

    for (int i = 2; i < n; ++i) {
        if (arr[i] > firstLargest)
		 {
            secondLargest = firstLargest;
            firstLargest = arr[i];
        } 
		else if (arr[i] > secondLargest && arr[i] != firstLargest)
		 {
            secondLargest = arr[i];
        }
    }

    cout << "Largest number: " << firstLargest<<endl;
    cout << "Second largest number: " << secondLargest;

    return 0;
}

