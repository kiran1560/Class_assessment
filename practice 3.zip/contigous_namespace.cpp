#include<iostream>
#include<fstream>
using namespace std;

namespace ns 
{
	int val=200;
}

namespace ns
 { 
 int fun(){
 
	cout<<"The value : "<<val;
}}

int main()
{
ns::fun();

return 0;
}
