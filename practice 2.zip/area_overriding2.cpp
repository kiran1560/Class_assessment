#include<iostream>
#include<math.h>
using namespace std;

class Shape
 {
public:
    virtual void area() {
        cout << "rectangle and triangle" << endl;
    }
};

class Rectangle : public Shape {
public:
    void area() 
	 {
        int b, h;
        cout <<"Enter the length and breadth of the rectangle: ";
        cin >> b>>h;
        int area = b*h;
        cout << "Area of rectangle: " << area << endl;
    }
};

class Triangle : public Shape {
public:
    void area() 
	 {
        int b, h;
        cout <<"Enter the base and height resp: ";
        cin >> b>>h;
        int area = (b*h)/2;
        cout << "Area of triangle: " << area << endl;
    }
};

class Sphere : public Shape {
public:
    void area() 
	 {
        int radius;
        const float pi=22/7;
        cout <<"Enter the radius: ";
        cin >> radius;
        float area = pi*radius*radius;
        cout << "Area of Sphere: " << area << endl;
    }
};

int main() {
    Rectangle r;
    Triangle t;
    Sphere sp;

    Shape *s1 = &r;
    Shape *s2 = &t;
    Shape *s3 = &sp;

    s1->area(); // can't use the dot operator, only use arrow operator
    s2->area();
    s3->area();

    return 0;
}

