#include<iostream>
using namespace std;

int main() {
    int n = 5;
    int arr[5];
    int target;
    bool repeatation = false;

    cout << "Enter the 5 elements of the array: " << endl;

    for (int i = 0; i < n; i++) 
	{
        cin >> arr[i];
    }

    //cout << "Enter the target number to check if it's repeated: ";
    //cin >> target;

    for (int i = 0; i < n; i++)
	 {
        if (arr[i] == repeatation)  //target
		{
          repeatation = true;
            //break; 
        }
    }

    if (repeatation)
	{
        cout << "True: The number " << arr[5] << " is repeated." << endl;
    } 
	else
	 {
        cout << "False: The number " << arr[5] << " is not repeated." << endl;
    }

    return 0;
}

