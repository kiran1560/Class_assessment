#include <iostream>
#include <string>
#include <sstream>

using namespace std;

int main() {
    string inputString;
    cout << "Enter a string: ";
    getline(cin, inputString);

    // Use stringstream to split the string into words
    stringstream ss(inputString);
    string word;
    int wordCount = 0;

    // Count the number of words
    while (ss >> word) {
        wordCount++;
    }

    cout << "Word count: " << wordCount << endl;

    return 0;
}

