#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char a[50];
    char b[50];
     cin>>a>>b;
     
     cout<<strcat(b,a);

    return 0;
}

