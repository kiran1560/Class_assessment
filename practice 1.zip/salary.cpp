#include <iostream>
#include <cstring>
using namespace std;

int main(){
	
	int salary;
	
	
	cin>>salary>>endl;
	
	if(salary> 15500)
	{
		cout<<"no need for increment"<<endl;
			
	}
	else
	{
		cout<<"need work"<<endl;
	}

}
