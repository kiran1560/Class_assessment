#include <iostream>

using namespace std;
class City
{
	public:
	void place(int a){
			cout<<"Delhi"<<endl;
		}
	void place(int a ,int b){
			cout<<"Punjab"<<endl;
		}
		void place(int a ,int b, int c){
			cout<<"Banglore"<<endl;
		}
};
int main(){
	City c;
	c.place(10);
	c.place(10,20);
	c.place(10,20,30);
}


//length

