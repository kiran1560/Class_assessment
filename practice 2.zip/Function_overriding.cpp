#include<iostream>
using namespace std;
class Base
{
	public:
		virtual void disp() //virtual keyword for deriving properties of base class into the derived class
		{
			cout<<"base class"<<endl;
		}
};
class Derived: public Base
{
	public:
		void disp()
		{
			cout<<"derived class"<<endl;
		}
};
int main(){
	Derived d;
	Base *b =&d;
	b->disp(); //cant use dot operator, only use arrow operator
	
}
