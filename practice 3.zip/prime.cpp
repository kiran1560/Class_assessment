//range given n and m , in ehich to find the count all prime pairs whose difference is 6. find how many sets are there in range for 1000
//op: 6 ,  i/p: 30
#include<iostream>
#include<cmath>
using namespace std;

bool isPrime(int num) {
    if (num <= 1) {
        return false;
    }
    for (int i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

void printPrimePairs(int n, int m) {
    cout << "Prime pairs with difference 6 in the range [" << n << ", " << m << "]:\n";
    for (int i = n; i <= m - 6; i++) {
        if (isPrime(i) && isPrime(i + 6)) {
            cout << "(" << i << ", " << i + 6 << ")\n";
        }
    }
}

int main() {
    int n, m;
    
    cout << "Enter the range (n and m): ";
    cin >> n >> m;

    if (n > m) {
        cout << "Invalid range." << endl;
        return 1;
    }

    printPrimePairs(n, m);

    return 0;
}

