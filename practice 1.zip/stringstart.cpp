#include <iostream>
#include <cstring>
using namespace std;

int main() {
    string s;
    getline(cin,s);
	 	cout<<s;

    return 0;
}

