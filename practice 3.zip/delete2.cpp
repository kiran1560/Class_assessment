#include <iostream>
using namespace std;

void del(int arr[],int target,int n)
{
int count = 0;

for(int i = 0; i < n; i++)
{
if(arr[i] == target)
count++;
}

int new_arr[n - count];
int ind = 0;
for(int i = 0; i < n; i++)
{
if(arr[i] != target)
{
new_arr[ind] = arr[i];
ind++;
}
}

int m = (sizeof(new_arr) /
sizeof(new_arr[0]));
for(int i = 0; i < m; i++)
{
cout << new_arr[i] << " ";
}
return;
}

int main()
{
int arr[5];
int target;
int n = (sizeof(arr) /sizeof(arr[0]));
cout<<"enter 5 elements of array"<<endl;
cin>>arr[5];
cout<<"Enter the target value: "<<endl;
cin>>target;


del(arr, target, n);
return 0;
}
