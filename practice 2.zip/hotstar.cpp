#include<iostream>
using namespace std;
class Hotstar
{
	public:
		virtual void subscription() //virtual keyword for deriving properties of base class into the derived class
		{
			cout<<"subscription"<<endl;
		}
};
class HotstarPrime: public Hotstar
{
	public:
		void subscription(){
			cout<<"with adds"<<endl;
		}
};
class HotstarGold: public Hotstar
{
	public:
		void subscription()
		{
			cout<<"without adds"<<endl;
		}
};

int main(){
	
	HotstarPrime hp;
	HotstarGold hg;
	
	Hotstar *h1 =&hp;
	Hotstar *h2 =&hg;
	
	h1->subscription(); //cant use dot operator, only use arrow operator
	h2->subscription();
	
	return 0;
}
